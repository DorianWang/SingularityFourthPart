
/**
 * Write a description of class Alarm here.
 * 
 * @author Dorian Wang
 * @version 1.0 May 12th, 2016
 */
public class Alarm
{
    ClockDisplay12 clock;
    boolean alarmOn;

    /**
     * Default, sets time to midnight and alarm to off.
     */
    public Alarm()
    {
        // initialise instance variables
        clock = new ClockDisplay12();
        alarmOn = false;
    }
    
    public Alarm(int hours, int minutes, String timeSuffix, boolean setAlarm)
    {
        // initialise instance variables
        clock = new ClockDisplay12(hours, minutes, timeSuffix);
        alarmOn = setAlarm;
    }

    /**
     * Sets the time of the internal clock.
     *
     */
    public void setTime(int hours, int minutes, String timeSuffix)
    {
        clock.setTime(hours, minutes, timeSuffix);
    }
    
    /**
     * Turns the alarm on.
     */
    public void turnOn()
    {
        alarmOn = true;
    }
    
    /**
     * Turns the alarm off.
     */
    public void turnOff()
    {
        alarmOn = false;
    }
    
    /**
     * Returns the current time in string form.
     * 
     * @return the string representing the current alarm time.
     */
    public String getTime()
    {
        return clock.getTime();
    }
    
    /**
     * Returns the current alarm setting.
     * 
     * @return the setting of the alarm.
     */
    public boolean isSet()
    {
        return alarmOn;
    }
    
}


























