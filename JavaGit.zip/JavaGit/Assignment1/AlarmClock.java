


/**
 * Write a description of class AlarmClock here.
 * 
 * @author Dorian Wang
 * @version 1.0 May 12th, 2016
 */
public class AlarmClock
{
    // instance variables - replace the example below with your own
    private ClockDisplay12 clock;
    private Alarm newAlarm;
    //bool alarmActive; //Using alarm bool in alarm

    /**
     * Default constructor, sets times of all clocks to midnight, with alarm off.
     */
    public AlarmClock()
    {
        // initialise instance variables
        clock = new ClockDisplay12();
        newAlarm = new Alarm();
    }
    
    /**
     * Constructor for objects of class AlarmClock
     */
    public AlarmClock(int hours, int minutes, String timeSuffix, int hoursAlarm,
                        int minutesAlarm, String timeSuffixAlarm, boolean alarmSet)
    {
        // initialise instance variables
        clock = new ClockDisplay12(hours, minutes, timeSuffix);
        newAlarm = new Alarm(hoursAlarm, minutesAlarm, timeSuffixAlarm, alarmSet);
    }

    /**
     * Sets the time of the internal clock.
     */
    public void setTime(int hours, int minutes, String timeSuffix)
    {
        clock.setTime(hours, minutes, timeSuffix);
    }
    
    /**
     * Sets the time of the internal alarm clock.
     */
    public void setAlarmTime(int hours, int minutes, String timeSuffix)
    {
        newAlarm.setTime(hours, minutes, timeSuffix);
    }
    
    /**
     * Makes the internal clock move forward one minute.
     */
    public void clockTick()
    {
        clock.timeTick();
        if (clock.getTime().equals(newAlarm.getTime())){
            System.out.println("RING RING RING");
        }
        
    }
    
    /**
     * Turns the alarm on.
     */
    public void setAlarm()
    {
        newAlarm.turnOn();// = true;
    }
    
    /**
     * Turns the alarm off.
     */
    public void unsetAlarm()
    {
        newAlarm.turnOff();// = true;
    }
    
    /**
     * Returns the time of the clock in string form.
     * 
     * @return the string representing the current clock time.
     */
    public String getTime()
    {
        return clock.getTime();
    }
    
    /**
     * Returns the time of the alarm in string form.
     * 
     * @return the string representing the current alarm time.
     */
    public String getAlarmTime()
    {
        return newAlarm.getTime();
    }
    
    /**
     * Returns the current alarm setting.
     * 
     * @return the setting of the alarm.
     */
    public boolean isAlarmSet()
    {
        return newAlarm.isSet();
    }
}























