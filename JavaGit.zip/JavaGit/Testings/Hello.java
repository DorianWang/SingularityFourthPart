
/**
 * Write a description of class Hello here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hello
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Hello
     */
    public Hello()
    {
        // initialise instance variables
        sampleMethod();
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void sampleMethod()
    {
        // put your code here
        TestList<String> ThingsTest = new TestList<String>("Hello world!");// = TestList<String>("Hello world!");
    }
}
