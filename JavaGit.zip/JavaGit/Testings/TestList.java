
/**
 * Write a description of class TestList here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestList<T>
{
    // instance variables - replace the example below with your own
    private T x;

    /**
     * Constructor for objects of class TestList
     */
    public TestList(T input)
    {
       sampleMethod(input);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public T sampleMethod(T y)
    {
        // put your code here
        System.out.println(y.toString());
        return y;
    }
}
