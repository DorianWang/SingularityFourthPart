/**
 * This class represents a simple picture. You can draw the picture using
 * the draw method. But wait, there's more: being an electronic picture, it
 * can be changed. You can set it to black-and-white display and back to
 * colors (only after it's been drawn, of course).
 *
 * This class was written as an early example for teaching Java with BlueJ.
 * 
 * @author  Michael K�lling and David J. Barnes
 * @version 2011.07.31
 */
public class Picture
{
    private Square background;
    private Square wall;
    private Square window;
    private Triangle roof;
    private Circle moon;
    private Circle moonCover;
    
    private final Integer moonHorizontal = 160;
    
    private Integer moonCoverHorizontal; //Starts on the right hand side.
    private boolean direction; //Left is true;

    /**
     * Constructor for objects of class Picture
     */
    public Picture()
    {
        // nothing to do... instance variables are automatically set to null
        
        //New! Now something to do!
        moonCoverHorizontal = moonHorizontal + 80;
        direction = true;
    }

    /**
     * Draw this picture.
     */
    public void draw()
    {
        background = new Square();
        background.changeColor("black");
        background.moveHorizontal(-320);
        background.moveVertical(-160);
        background.changeSize(5000);
        background.makeVisible();
        
        wall = new Square();
        wall.moveHorizontal(-140);
        wall.moveVertical(20);
        wall.changeSize(120);
        wall.makeVisible();
        
        window = new Square();
        window.changeColor("black");
        window.moveHorizontal(-120);
        window.moveVertical(40);
        window.changeSize(40);
        window.makeVisible();

        roof = new Triangle();  
        roof.changeSize(60, 180);
        roof.moveHorizontal(20);
        roof.moveVertical(-60);
        roof.makeVisible();

        moon = new Circle();
        moon.changeColor("blue");
        moon.moveHorizontal(moonHorizontal);
        moon.moveVertical(-30);
        moon.changeSize(80);
        moon.makeVisible();
        
        moonCover = new Circle();
        moonCover.changeColor("black");
        moonCover.moveHorizontal(moonCoverHorizontal);
        moonCover.moveVertical(-30);
        moonCover.changeSize(80);
        moonCover.makeVisible();
    }

    /**
     * Change this picture to black/white display
     */
    public void setBlackAndWhite()
    {
        if (wall != null)   // only if it's painted already...
        {
            background.changeColor("black");
            wall.changeColor("black");
            window.changeColor("white");
            roof.changeColor("black");
            moon.changeColor("black");
            moonCover.changeColor("white");
        }
    }

    /**
     * Change this picture to use color display
     */
    public void setColor()
    {
        if (wall != null)   // only if it's painted already...
        {
            background.changeColor("black");
            wall.changeColor("red");
            window.changeColor("black");
            roof.changeColor("green");
            moon.changeColor("blue");
            moonCover.changeColor("black");
        }
    }
    
        /**
     * Does moon things
     */
    public void setMoonHorizontal()
    {
        if (moonCoverHorizontal >= moonHorizontal + 80 && direction == false){
            direction = true;
        }
        else if (moonCoverHorizontal <= moonHorizontal - 80 && direction == true){
            direction = false;
        }
        else if (direction == true)   // 
        {
            moonCoverHorizontal = moonCoverHorizontal - 20;
        }
        else
        {
            moonCoverHorizontal = moonCoverHorizontal + 20;
        }
    }
    
    public void animation()
    {
        // How to make tasty tasty pasta.
        draw();
        for (int i = 0; i < 18; i++){
            moon = new Circle();
            moon.changeColor("blue");
            moon.moveHorizontal(moonHorizontal);
            moon.moveVertical(-30);
            moon.changeSize(80);
            moon.makeVisible();
        
            moonCover = new Circle();
            moonCover.changeColor("black");
            moonCover.moveHorizontal(moonCoverHorizontal);
            moonCover.moveVertical(-30);
            moonCover.changeSize(80);
            moonCover.makeVisible();
            setMoonHorizontal();
            try {
               Thread.sleep(1000);// 1000 milliseconds?
            }
            catch(InterruptedException e)
            {
                //I hope I don't catch anything...
            }
        }
    }
}


















