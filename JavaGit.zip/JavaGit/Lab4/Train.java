public class Train
{
   
    public Train(int numberOfCars)
    {

    }
   
    public void addCar(Car car)
    {

    }
   
    public boolean issueTicket(boolean requestedClass)
    {
        return false;
    }
   
    public boolean cancelTicket(int id, int seatNo)
    {
        return false;
    }
}
